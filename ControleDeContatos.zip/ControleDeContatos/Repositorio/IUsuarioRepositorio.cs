﻿using ControleDeContatos.Models;

namespace ControleDeContatos.Repositorio
{
    public interface IUsuarioRepositorio
    {
        UsuarioModel BuscarPorEmailELogin(string email, string login);
        UsuarioModel BuscarPorLogin(string login);

        UsuarioModel ListarPorId(int id);

        UsuarioModel Adicionar(UsuarioModel usuario);

        UsuarioModel Alterar(UsuarioModel usuario);

        void Atualizar(UsuarioModel usuario);
        List<UsuarioModel> BuscarTodos();
        UsuarioModel AlterarSenha(AlterarSenhaModell alterarSenhaModell);
        bool Apagar(int id);
    }
}
