﻿using Microsoft.AspNetCore.Mvc;

namespace ControleDeContatos.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
