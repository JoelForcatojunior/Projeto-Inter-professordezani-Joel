﻿using ControleDeContatos.Data;
using ControleDeContatos.Models;
using System;

namespace ControleDeContatos.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly BancoContext _bancoContext;
        public UsuarioRepositorio(BancoContext bancoContext) 
        {
            this._bancoContext = bancoContext;
        }

        public UsuarioModel BuscarPorEmailELogin(string email, string login)
        {
            return _bancoContext.Usuarios.FirstOrDefault(x => x.Email.ToUpper() == email.ToUpper() && x.Login.ToUpper() == login.ToUpper());
        }

        public UsuarioModel BuscarPorLogin(string login)
        {
            return _bancoContext.Usuarios.FirstOrDefault(x => x.Login.ToUpper() == login.ToUpper());
        }

        public UsuarioModel ListarPorId(int Id)
        {
            return _bancoContext.Usuarios.FirstOrDefault(x => x.Id == Id);
        }



        public UsuarioModel Adicionar(UsuarioModel usuario)
        {
            try { 
            usuario.DataCadastro = DateTime.Now;
                usuario.SetSenhaHash()
    ;            _bancoContext.Usuarios.Add(usuario);
            _bancoContext.SaveChanges();
            }
            catch (Exception ex) 
            {
                throw new Exception("Erro ao cadastrar o usuário. Detalhes: " + ex.Message, ex);
            }

            return usuario;
        }


        public void Atualizar(UsuarioModel usuario)
        {
            var usuarioDB = _bancoContext.Usuarios.Find(usuario.Id);

            if (usuarioDB == null)
                throw new Exception("Usuário não encontrado!");

            usuarioDB.Nome = usuario.Nome;
            usuarioDB.Email = usuario.Email;
            usuarioDB.Login = usuario.Login;


            _bancoContext.SaveChanges();
        }

        public List<UsuarioModel> BuscarTodos()
        {
            return _bancoContext.Usuarios.ToList();
        }

        public bool Apagar(int id)
        {
            UsuarioModel usuarioDB = ListarPorId(id);

            if (usuarioDB == null)
                throw new Exception("Usuario não encontrado!");

            _bancoContext.Usuarios.Remove(usuarioDB);
            _bancoContext.SaveChanges();

            return true;
        }



        public UsuarioModel AlterarSenha(AlterarSenhaModell alterarSenhaModell)
        {
            UsuarioModel usuarioDB = ListarPorId(alterarSenhaModell.id);

            if (usuarioDB == null) throw new Exception("Houve um erro na atualização da senha, usuario não encontrado");

            if (usuarioDB.SenhaValida(alterarSenhaModell.SenhaAtual)) throw new Exception("Senha Atual não confere!");

            if (usuarioDB.SenhaValida(alterarSenhaModell.NovaSenha)) throw new Exception("Nova senha deve ser diferente da senha atual!");

            usuarioDB.SetNovaSenha(alterarSenhaModell.NovaSenha);
            usuarioDB.DataAtualizacao = DateTime.Now;

            _bancoContext.Usuarios.Update(usuarioDB);

            _bancoContext.SaveChanges();

            return usuarioDB;

        }







        public UsuarioModel Alterar(UsuarioModel usuario)
        {
            UsuarioModel usuarioDB = ListarPorId(usuario.Id);

            if (usuarioDB == null)
                throw new Exception("Usuario não encontrado!");

            usuarioDB.Nome = usuario.Nome;

            usuarioDB.Email = usuario.Email;

            usuarioDB.Login = usuario.Login;

            usuarioDB.Perfil = usuario.Perfil;

            _bancoContext.Usuarios.Update(usuarioDB);

            _bancoContext.SaveChanges();

            return usuarioDB;
        }


    }
}
