﻿namespace ControleDeContatos.Models
{
    public class HomeModel
    {
        public string? Nome { get; set; }
        public string? Email { get; set; }

    }
}
