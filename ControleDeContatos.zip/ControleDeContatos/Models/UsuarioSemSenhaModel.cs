﻿using ControleDeContatos.Enums;
using System.ComponentModel.DataAnnotations;

namespace ControleDeContatos.Models
{
    public class UsuarioSemSenhaModel
    {
        public int Id{ get; set; }

        [Required(ErrorMessage = "Digite o Nome do Contato")]
        public string Nome{ get; set; }


        [Required(ErrorMessage = "Digite o Login do Contato")]
        public string Login{ get; set; }


        [Required(ErrorMessage = "Digite o Email do Contato")]
        [EmailAddress(ErrorMessage = "O e-mail informado não é válido!")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Digite a perfil do Contato")]
        public PerfilEnum? Perfil { get; set; }

        public DateTime? DataAtualizacao { get; set; }
    }
}
