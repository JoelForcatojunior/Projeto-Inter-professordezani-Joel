﻿using ControleDeContatos.Data;
using ControleDeContatos.Models;

namespace ControleDeContatos.Repositorio
{
    public class ContatoRepositorio : IContatoRepositorio
    {
        private readonly BancoContext _bancoContext;
        public ContatoRepositorio(BancoContext bancoContext) 
        {
            this._bancoContext = bancoContext;
        }

        public ContatoModel ListarPorId(int Id)
        {
            return _bancoContext.Contatos.FirstOrDefault(x => x.Id == Id);
        }



        public ContatoModel Adicionar(ContatoModel contato)
        {   
            _bancoContext.Contatos.Add(contato);
            _bancoContext.SaveChanges();


            return contato;
        }
        public List<ContatoModel> BuscarTodos()
        {
            return _bancoContext.Contatos.ToList();
        }


        public void Atualizar(ContatoModel contato)
        {
            var contatoDB = _bancoContext.Contatos.Find(contato.Id);

            if (contatoDB == null)
                throw new Exception("Contato não encontrado!");

            contatoDB.Nome = contato.Nome;
            contatoDB.Email = contato.Email;
            contatoDB.Celular = contato.Celular;

            _bancoContext.SaveChanges();
        }


        public ContatoModel Alterar(ContatoModel contato)
        {
            ContatoModel contatoDB = ListarPorId(contato.Id);

            if (contatoDB == null)
                throw new Exception("Contato não encontrado!");

            contatoDB.Nome = contato.Nome;

            contatoDB.Email = contato.Email;

            contatoDB.Celular = contato.Celular;

            _bancoContext.Contatos.Update(contatoDB);

            _bancoContext.SaveChanges();

            return contatoDB;
        }

        public bool Apagar(int id)
        {
            ContatoModel contatoDB = ListarPorId(id);

            if (contatoDB == null)
                throw new Exception("Contato não encontrado!");

            _bancoContext.Contatos.Remove(contatoDB);
            _bancoContext.SaveChanges();

            return true;
        }
    }
}
