﻿using ControleDeContatos.Models;

namespace ControleDeContatos.Repositorio
{
    public interface IContatoRepositorio
    {
        

        ContatoModel ListarPorId(int id);
        ContatoModel Adicionar(ContatoModel contato);

        ContatoModel Alterar(ContatoModel contato);
        void Atualizar(ContatoModel contato);
        List<ContatoModel> BuscarTodos();

        bool Apagar(int id);
    }
}
